<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" type="text/css" href="stylesheets/reboot.css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:700" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="stylesheets/nav.css">
    <title>Navigation bar template</title>
</head>
<body>
<nav class="Navbar" id="navbar">
    <div class="Container" id="container">
        <div id="navbar-left">
            <a href="#" class="LinkItem-Left">
                <!--image must be 50x50px-->
                <img src="img/logo.png" id="logo" height="50" width="50" alt="">
                &#32;My Website
            </a>
            <a href="javascript:void(0)" id="menuIcon" onclick="toggleResponsiveClass()">&equiv;</a>
        </div>
        <div id="navbar-right" class="Navbar-Right">
            <a href="#" class="LinkItem LinkItem-Right" id="item1">Page 1</a>
            <a href="#" class="LinkItem LinkItem-Right" id="item2">Page 2</a>
            <a href="#" class="LinkItem LinkItem-Right" id="item3">Page 3</a>
            <a href="#" class="LinkItem LinkItem-Right" id="item4">Page 4</a>
            <a href="#" class="LinkItem LinkItem-Right" id="item5">Page 5</a>
        </div>
    </div>
</nav>
<script src="js/script.js"></script>
</body>
</html>