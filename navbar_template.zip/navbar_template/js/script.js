function toggleResponsiveClass() {
    let a = document.getElementById("navbar");
    let b = document.getElementById("container");
    let c = document.getElementById("navbar-right");
    //alter one variable for every new or removed menu item
    let d = document.getElementById("item1");
    let e = document.getElementById("item2");
    let f = document.getElementById("item3");
    let g = document.getElementById("item4");
    let h = document.getElementById("item5");

    if (//alter one classname for every new/removed menu item
        a.className === "Navbar" ||
        b.className === "Container" ||
        c.className === "navbar-right" ||
        d.className === "LinkItem LinkItem-Right" ||
        e.className === "LinkItem LinkItem-Right" ||
        f.className === "LinkItem LinkItem-Right" ||
        g.className === "LinkItem LinkItem-Right" ||
        h.className === "LinkItem LinkItem-Right") {
        //alter one " Responsive" for every new or removed menu item
        a.className += " Responsive";
        b.className += " Responsive";
        c.className += " Responsive";
        d.className += " Responsive";
        e.className += " Responsive";
        f.className += " Responsive";
        g.className += " Responsive";
        h.className += " Responsive";
    } else {
        a.className = "Navbar";
        b.className = "Container";
        c.className = "Navbar-Right";
        //alter one "Link Item LinkItem-Right" for every new or removed menu item
        d.className = "LinkItem LinkItem-Right";
        e.className = "LinkItem LinkItem-Right";
        f.className = "LinkItem LinkItem-Right";
        g.className = "LinkItem LinkItem-Right";
        h.className = "LinkItem LinkItem-Right";
    }
}